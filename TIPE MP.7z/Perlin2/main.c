#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <SDL/SDL.h>

#include "calque.h"
#include "main.h"


void colorerPixel(SDL_Surface* s, int x, int y, Uint32 coul){
    *((Uint32*)(s->pixels) + x + y * s->w) = coul;
}

// fourni une valeur entre 0 et a
unsigned char aleatoire(float a){
    return (float)rand() / RAND_MAX * a;
}


void enregistrer_bmp(struct calque *c, const char *filename){

    SDL_Surface *s = SDL_CreateRGBSurface(SDL_SWSURFACE,c->taille, c->taille, 32,0, 0, 0, 0);
    if (!s)
        printf("erreur SDL sur SDL_CreateRGBSurface");

    int i,j;
    Uint32 u;
    SDL_PixelFormat *fmt = s->format;
    for (i=0; i<c->taille; i++)
        for (j=0; j<c->taille; j++){
            u = SDL_MapRGB  (fmt, (char)c->v[i][j], (char)c->v[i][j], (char)c->v[i][j]);
            colorerPixel(s, i, j, u);
        }

    SDL_SaveBMP(s, filename);
    SDL_FreeSurface(s);
}

int main(int argc, char **argv)
{
    srand((int)time(NULL));
    //srand(6);

    // valeurs d'entr�e
	int octaves=3;
	int frequence=4;
	float persistence=.5;
    int taille_de_sortie=200;
    int lissage = 3;

    // cr�ation de calque
    struct calque *s;

    // initailisation du calque
    s=init_calque(taille_de_sortie,1);
    if (!s)
        return 1;

    generer_calque(frequence,
                   octaves,
                   persistence,
                   lissage,
                   s);

    enregistrer_bmp(s, "resultat.bmp");

	return 0;
}

// end of file
