#ifndef __calque_h__
#define __calque_h__

struct calque{
    int **v;
    int taille;
    float persistance;
};

struct calque* init_calque(int, float);
void free_calque(struct calque*);
void generer_calque(int, int, float, int, struct calque*);
int interpolate(int, int, int, int);
int valeur_interpolee(int, int, int, struct calque*);

#endif
