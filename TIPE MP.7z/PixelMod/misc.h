#ifndef MISC_H_INCLUDED
#define MISC_H_INCLUDED

void pause();
void randomcolor(int n, int tabular[], int tabsize);

void randomgen(int n, int tabular[], int tabsize);
void randomgen2(int n, int tabular[], int tabsize);
void randomgen3(int n, int tabular[], int tabsize);
void randomgen4(int n, int tabular[], int tabsize);

#endif // MISC_H_INCLUDED
