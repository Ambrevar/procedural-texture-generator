#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL.h>


// Bug si activ� !!!!!!!!!!!????????????
// #include "misc.h"
// #include "pixeldraw.h"

// A mettre en argument.
#define WIDTH 256
#define HEIGHT 256

// Donn�es de la texture :
// dimensions, randomgen value, persistance, octaves, ...


int main(int argc, char *argv[])
{
    if (SDL_Init(SDL_INIT_VIDEO) == -1) // D�marrage de la SDL. Si erreur alors...
    {
        fprintf(stderr, "Erreur d'initialisation de la SDL : %s\n", SDL_GetError()); // Ecriture de l'erreur
        exit(EXIT_FAILURE); // On quitte le programme
    }

    SDL_WM_SetCaption("PixelMod - Version 0.2", NULL);


    SDL_Surface *ecran = NULL;
    ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE);
// Autres param�tres :
// SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE); //  | SDL_RESIZABLE | SDL_DOUBLEBUF
// A virer du TIPE


// Tester si pas de probl�me pour assigner ecran.
    if (ecran == NULL)
    {
        fprintf(stderr, "Pb d'initialisation de l'image : %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }

// Remplir "ecran" en blanc.
    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));





// G�n�ration 2D

// Param�tres de la texture.

// Qq exemples :
// 123 2 1 3
// 5463 2 2 4

    int seed = 34567;
    srand(seed);

    int maxOctaves = 1;
    double persistance = 0.3;
    int pasFondamental = 6;
    int calque[maxOctaves][WIDTH][HEIGHT];

    int octave;
    int i,j;
    int y;
    int x;
    int pas;
    double amplitude;



// G�n�ration de toutes les octaves.
    for (octave=0; octave<maxOctaves; octave++)
    // for (octave=0; octave<2; octave++)
    {

        pas = pow(2,pasFondamental-octave);

        amplitude = pow(persistance,octave);

    // Dessin des noeuds.
        for (i=0; i<WIDTH/pas; i++)
        {
            for (j=0; j<HEIGHT/pas; j++)
            {
                if (octave == 0)
                {
                    calque[octave][i*pas][j*pas] = rand() % 256;
                }
                else
                {
                    // calque[octave][i*pas][j*pas] = 127 + (calque[octave-1][i*pas][j*pas]-127)*amplitude;
                    calque[octave][i*pas][j*pas] = calque[octave-1][i*pas][j*pas]*amplitude;
                }
                // draw(ecran, 8, 8, calque[octave][i*pas][j*pas],calque[octave][i*pas][j*pas],calque[octave][i*pas][j*pas], pas*i, pas*j);
            }
        }

    // Interpolation.

        // int precision = 50 -> Inutile en 2D ?

        for (j=0; j<HEIGHT/pas-1; j++)
        {
            for (i=0; i<WIDTH/pas-1; i++)
            {
                for (x = i*pas; x <= (i+1)*pas; x++)
                {
                    y = j*pas;
                    calque[octave][x][y] = interpolation1d( calque[octave][i*pas][y], calque[octave][(i+1)*pas][y], (double) (x-i*pas)/pas);
                    calque[octave][x][y+pas] = interpolation1d( calque[octave][i*pas][y+pas], calque[octave][(i+1)*pas][y+pas], (double) (x-i*pas)/pas);

                    draw(ecran, 1, 1, calque[octave][x][y],calque[octave][x][y],calque[octave][x][y], x,y);
                    draw(ecran, 1, 1, calque[octave][x][y+pas],calque[octave][x][y+pas],calque[octave][x][y+pas], x, y+pas);

                    for (y = j*pas; y < (j+1)*pas; y++)
                    {
                        calque[octave][x][y] = interpolation1d( calque[octave][x][j*pas], calque[octave][x][(j+1)*pas], (double) (y-j*pas)/pas);
                        draw(ecran, 1, 1, calque[octave][x][y],calque[octave][x][y],calque[octave][x][y], x,y);
                    }
                }
            }
        }
    }


// Fusion des calques.
    int calqueFinal[WIDTH][HEIGHT];
    for (x = 0; x < WIDTH; x++) {
        for (y = 0; y < WIDTH; y++) {
            calqueFinal[x][y] = 0;
        }
    }

    for (octave=0; octave<maxOctaves; octave++)
    {
        double amplitude = pow(persistance,octave);

        for (x = 0; x < WIDTH; x++) {
            for (y = 0; y < WIDTH; y++) {
//                if (calqueFinal[x][y]+calque[octave][x][y]*amplitude/maxOctaves > 255)
//                {
//                    calqueFinal[x][y] = 255;
//                }
//                else
//                {
                calqueFinal[x][y] = calqueFinal[x][y]+calque[octave][x][y]*amplitude;
                //}
            }
        }
    }



// Dessin final.
    for (x = 0; x < WIDTH; x++) {
        for (y = 0; y < WIDTH; y++) {
           // draw(ecran, 1, 1, calqueFinal[x][y],calqueFinal[x][y],calqueFinal[x][y], x,y);
        }
    }

// Fin.










// LOG ONLY
    FILE* output = NULL;
    output = fopen("output.txt", "a");
    if (output != NULL)
    {
        fprintf(output, "\nDebut du log\n");
//        fprintf(output, "interpol=%d\n", interpolation1d( calque[octave][0][y], calque[octave][pas][y], (double) 5/pas));
//        fprintf(output, "x1=%d, x2=%d,x=%f\n", calque[octave][0][pas+1], calque[octave][0][2*pas-1],(double) 5/pas);
        fclose(output); // On ferme le fichier qui a �t� ouvert
    }









// Actualisation finale indispensable (sinon ne s'affiche pas).
// Pause sinon se ferme automatiquement.
    SDL_Flip(ecran);
    pause();

// On lib�re l'espace pris.

    SDL_Quit();

    return EXIT_SUCCESS;
}

