#include <SDL/SDL.h>

// Fonction trouv�e dans un tutorial SDL.
void pause()
{
    int continuer = 1;
    SDL_Event event;

    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
        }
    }
}

void randomcolor(int tabular[], int tabsize)
{
    int i;
    for (i = 0; i< tabsize; i++)
    {
        tabular[i] = rand() % 256;
    }
}


void randomgen(int n, int tabular[], int tabsize)
{
    int i;
    tabular[0] = 12;
    tabular[1] = 3267812;
    tabular[2] = 2357;
    tabular[3] = 1432345788;
    tabular[4] = 2354;
    tabular[5] = 867;
    tabular[6] = 23;
    tabular[7] = 1287643;
    tabular[8] = 98423;
    tabular[9] = 576850;
}

void randomgen2(int n, int tabular[], int tabsize)
{
    int i;
    int p=n;
    for (i=0; i< tabsize; i++)
    {
        // Nombre premiers : 15731   789221    1376312589   1073741824
        p = p % 1376312589;
        if (p<0) p = -p;
        tabular[i] = p;
    }
}


void randomgen3(int n, int tabular[], int tabsize)
{
    int i;
    int p=n;
    for (i=0; i< tabsize; i++)
    {
        // Nombre premiers : 15731   789221    1376312589   1073741824
        p = ((((((n+i+1)%2)*93 + ((n+i)%3))*575 + ((n+i)%13))*789221 + ((n+i)%7))*1376312589);
        if (p<0) p = -p;
        tabular[i] = p;
    }
}

void randomgen4(int n, int tabular[], int tabsize)
{
    int i;
    int p=n;
    for (i=0; i< tabsize; i++)
    {
        // Nombre premiers : 15731   789221    1376312589   1073741824
        p =  ((n*i) * ((n*i) * (n*i) * 15731 + 789221) + 1376312589) + n / 1073741824;
        if (p<0) p = -p;
        tabular[i] = p;
    }
}
