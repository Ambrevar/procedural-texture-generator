#ifndef PIXELOPS_H_INCLUDED
#define PIXELOPS_H_INCLUDED

Uint32 obtenirPixel(SDL_Surface *surface, int x, int y);
void definirPixel(SDL_Surface *surface, int x, int y, Uint32 pixel);

#endif // PIXELOPS_H_INCLUDED
