#include <SDL/SDL.h>
#include <math.h>

void draw(SDL_Surface *ecran, int width, int height, int RED, int GREEN, int BLUE, int x, int y)
{
    SDL_Surface *rectangle = NULL;
    rectangle = NULL;
    rectangle = SDL_CreateRGBSurface(SDL_HWSURFACE, width, height, 32, 0, 0, 0, 0);
    SDL_FillRect(rectangle, NULL, SDL_MapRGB(ecran->format, RED, GREEN, BLUE));
    SDL_Rect position;
    position.x = x;
    position.y = y;
    SDL_BlitSurface(rectangle, NULL, ecran, &position);

    // On lib�re la m�moire.
    SDL_FreeSurface(rectangle);
}

int interpolation1d(int y1, int y2, double x)
{
    // return (int) ( y1*(cos(x * 3.14159)+1) / 2 + y2*(1-cos(x * 3.14159)) / 2);
    return (int) y1*(1-x) + y2*x;
}
