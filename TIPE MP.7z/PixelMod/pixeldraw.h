#ifndef PIXELDRAW_H_INCLUDED
#define PIXELDRAW_H_INCLUDED

void draw(SDL_Surface *ecran, int width, int height, int RED, int GREEN, int BLUE, int x, int y);
double interpolation1d(double y1, double y2, double x);

#endif // PIXELDRAW_H_INCLUDED
