

// G�n�ration du tableau 1D.

    int tabsize = 10;
    int tableau[tabsize];

    randomgen(123232098, tableau, tabsize);
    // Variable pour le parcours du tableau.


    int abscisses[tabsize];
    for (i=0; i<tabsize; i++)
    {
        if (i*WIDTH / (tabsize-1) == WIDTH) abscisses[i]=WIDTH-1;
        else abscisses[i]=i*WIDTH / (tabsize-1);
        // A RETRAVAILLER pour une plus belle expression.
    }


// Dessin des points.

    for (i=0; i<tabsize; i++)
    {
        draw(ecran, 4, 4, 255,0,0, abscisses[i], tableau[i] % HEIGHT);
    }

// Interpolation 1D
    // Le facteur de pr�cision permet de tracer une belle courbe.
    int precision = 50;
    // On interpole entre deux points donn�s par les abscisses et leurs valeurs associ�es.
    int x1,x2;
    int y1,y2;
    // La variable x parcourt l'intervalle d�fini par les deux abscisses.
    int x;
    double varInterpolationA; // Raccourci.
    double varInterpolationB; // Raccourci.
    double varInterpolationC; // Raccourci.

    for (i=0; i<tabsize-1; i++)
    {
        x1 = abscisses[i];
        x2 = abscisses[i+1];
        y1 = tableau[i] % HEIGHT; // La division est n�cessaire pour s'assurer qu'on ne sort pas du dessin.
        y2 = tableau[i+1] % HEIGHT;


        for (x = 1; x/precision <= (x2-x1); x++)
        {
            varInterpolationA = (double) (x-1) / (x2-x1) / precision ;
            varInterpolationB = (double) x / (x2-x1) / precision ;
            varInterpolationC = (double) (x+1) / (x2-x1) / precision ;
            draw(ecran, 1, 1, 0,0,0, x1 + x/precision, interpolation1d( y1, y2, varInterpolationB));
        }
    }


 // SMOOTH CODE ??????
