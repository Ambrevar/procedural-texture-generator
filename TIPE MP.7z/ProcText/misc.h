#ifndef MISC_H_INCLUDED
#define MISC_H_INCLUDED

void pause();

void randomgen(int n);

void randomgen2(int n, int prevValue);

void randomcolor(int n);

#endif // MISC_H_INCLUDED
