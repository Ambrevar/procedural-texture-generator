#ifndef CALC_H_INCLUDED
#define CALC_H_INCLUDED


calque* init_calque(int t, float p);

void free_calque(struct calque* s);

void lissage(calque* fusion, int taille);

#endif
