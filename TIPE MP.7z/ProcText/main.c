#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL.h>


// Bug si activ� !!!!!!!!!!!????????????
// #include "misc.h"
// #include "pixeldraw.h"

// A mettre en argument.
#define WIDTH 256
#define HEIGHT 256

// Donn�es de la texture :
// dimensions, randomgen value, persistance, octaves, ...





int main(int argc, char *argv[])
{
    if (SDL_Init(SDL_INIT_VIDEO) == -1) // D�marrage de la SDL. Si erreur alors...
    {
        fprintf(stderr, "Erreur d'initialisation de la SDL : %s\n", SDL_GetError()); // Ecriture de l'erreur
        exit(EXIT_FAILURE); // On quitte le programme
    }

    SDL_WM_SetCaption("PixelMod - Version 0.2", NULL);


// On g�n�re l'�cran, i.e. la surface sur laquelle on dessine.
    SDL_Surface *ecran = NULL;
    ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE);
// Autres param�tres :
// SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE); //  | SDL_RESIZABLE | SDL_DOUBLEBUF
// A virer du TIPE


// Tester si pas de probl�me pour assigner ecran.
    if (ecran == NULL)
    {
        fprintf(stderr, "Pb d'initialisation de l'image : %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }

// Remplir "ecran" en blanc.
    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));

// Param�tres
    int seed = 531235;
    srand(seed);

    int nbOctaves = 5;
    float persistance2 = 0.4;
    // Si on veut que le pas (tailleCell) reste constant, on pose :
    //            frequence = WIDTH / pas
    // avec "pas" le param�tre rempla�ant "frequence" en entr�e.
    int frequence = 2;





// Initialisation

    typedef struct calque calque;
    struct calque
    {
        int **v;
        int taille;
        float persistance;
    };

    // Les indices pour les octaves, 1�re et 2�me coordonn�es.
    int n,i,j;





// Cr�ation du calque de base.

    calque* base;
    base = init_calque(WIDTH, 1);


    for (i=0; i<WIDTH; i++){
        for (j=0; j<HEIGHT; j++){
            base->v[i][j]=randomgen(255);
            // draw(ecran, WIDTH, HEIGHT, base->v[i][j], base->v[i][j], base->v[i][j], i, j);
        }
    }




// Cr�ation des octaves.
    calque** octave;
    octave = malloc(nbOctaves);
    for (n=0; n<nbOctaves; n++){
        octave[n] = init_calque(WIDTH, persistance2);
        persistance2*=persistance2;
    }







// DEBUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG

// Remarque : ici, on interpole toujours depuis la base, mais quid de l'interpolation depuis le calque pr�c�dant ?
    for (n=0; n<nbOctaves; n++){
        for (i=0; i<WIDTH; i++){
            for (j=0; j<WIDTH; j++){

                //octave[n]->v[i][j] = interpol(base,frequence,i,j);
                octave[n]->v[i][j] = valeur_interpolee(i,j,frequence,base);

            }
        }
    frequence*=frequence;
    }



    // int var = interpol(base,2,3,5);
    // float var2 = octave[2]->persistance;

// DEBUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG BUG








// Fusion des calques
    calque* fusion;
    fusion = init_calque(WIDTH, 1);


    int sum_persistances = 0;
    for (n=0; n<nbOctaves; n++){
        sum_persistances += octave[i]->persistance;
    }


    for (i=0; i<WIDTH; i++){
        for (j=0; j<WIDTH; j++){
            fusion->v[i][j] = 0;
        }
    }

// Attention aux incoh�rences !

    for (i=0; i<WIDTH; i++){
        for (j=0; j<WIDTH; j++){
            for (n=0; n<nbOctaves; n++){
                fusion->v[i][j] += octave[n]->v[i][j]*octave[n]->persistance;
            }
        // fusion->v[i][j] =  fusion->v[i][j] / sum_persistances;
        }
    }


// Lissage final.
    // lissage(fusion, WIDTH);

// Dessin final.
    for (i=0; i<WIDTH; i++){
        for (j=0; j<WIDTH; j++){
            draw(ecran, WIDTH, HEIGHT, fusion->v[i][j], fusion->v[i][j], fusion->v[i][j], i, j);
        }
    }











//// LOG ONLY
//    FILE* output = NULL;
//    output = fopen("output.txt", "a");
//    if (output != NULL)
//    {
//        fprintf(output, "\nDebut du log:\n");
//        fprintf(output, "-------------\n");
//        // fprintf(output, "Valeur : %f\n\n",var2);
//        fclose(output); // On ferme le fichier qui a �t� ouvert
//    }





// Actualisation finale indispensable (sinon ne s'affiche pas).
// Pause sinon se ferme automatiquement.
    SDL_Flip(ecran);
    pause();

// On lib�re l'espace pris.

    SDL_Quit();

    return EXIT_SUCCESS;
}

