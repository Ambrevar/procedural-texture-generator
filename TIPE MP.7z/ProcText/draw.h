#ifndef PIXELDRAW_H_INCLUDED
#define PIXELDRAW_H_INCLUDED

void draw(SDL_Surface *ecran, int width, int height, int RED, int GREEN, int BLUE, int x, int y);

int interpol(calque* base, int frequence, int i, int j);

int valeur_interpolee(int i, int j, int frequence, struct calque *r);

int interpolate(int y1, int y2, int n, int delta);

void lissage(calque* fusion, int taille);

#endif // PIXELDRAW_H_INCLUDED
