typedef struct calque calque;
struct calque
{
    int **v;
    int taille;
    float persistance;
};


calque* init_calque(int t, float p){
    calque *s = malloc( sizeof(struct calque) );
    s->v = malloc(t * sizeof(int*));
    int i,j;
    for (i = 0; i < t ; i++){
        s->v[i]= malloc(t*sizeof(int));
        for (j=0; j<t; j++)
            s->v[i][j] = 0;
    }
    s->taille = t;
    s->persistance = p;

    return s;
}

void free_calque(struct calque* s){
    int j;
    for (j=0; j<s->taille; j++){
        free(s->v[j]);
    }
    free(s->v);
}
