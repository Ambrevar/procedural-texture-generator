#include <SDL/SDL.h>
#include <math.h>


typedef struct calque calque;
struct calque
{
    int **v;
    int taille;
    float persistance;
};


void draw(SDL_Surface *ecran, int width, int height, int red, int green, int blue, int x, int y)
{
    SDL_Surface *rectangle = NULL;
    rectangle = NULL;
    rectangle = SDL_CreateRGBSurface(SDL_HWSURFACE, width, height, 32, 0, 0, 0, 0);
    SDL_FillRect(rectangle, NULL, SDL_MapRGB(ecran->format, red, green, blue));
    SDL_Rect position;
    position.x = x;
    position.y = y;
    SDL_BlitSurface(rectangle, NULL, ecran, &position);

    // On lib�re la m�moire.
    SDL_FreeSurface(rectangle);
}



int interpol(calque* base, int frequence, int i, int j){

    int tailleCell = base->taille/frequence;

    // D�finitions des bornes d'interpolation :
    int minX = (i/tailleCell) * tailleCell;
    int minY = (j/tailleCell) * tailleCell;

    int maxX=base->taille-1;
    int maxY=base->taille-1;
    if (i<tailleCell*frequence) maxX = minX + tailleCell;
    if (j<tailleCell*frequence) maxY = minY + tailleCell;

    // Variable d'interpolation :
    float x = (float) (i % tailleCell) / tailleCell;
    float y = (float) (j % tailleCell) / tailleCell;

    // On interpole en x :
    int A = base->v[minX][minY] * (1+cos(3.1415 * x))/2 + base->v[maxX][minY] * (1-cos(3.1415 *x))/2;
    int B = base->v[minX][maxY] * (1+cos(3.1415 * x))/2 + base->v[maxX][maxY] * (1-cos(3.1415 *x))/2;

    // On renvoie l'interpolation en y des deux r�sultats pr�c�dents.
    return (int) A*(cos(3.1415 * y)+1)/2 + B*(1-cos(3.1415 *y))/2;
}



int valeur_interpolee(int i, int j, int frequence, struct calque *r){
	/* d�terminations des bornes */
	int borne1x, borne1y, borne2x, borne2y, q;
	float pas;
	pas = (float)r->taille/frequence;

	q = (float)i/pas;
	borne1x = q*pas;
	borne2x = (q+1)*pas;

	if(borne2x >= r->taille)
		borne2x = r->taille-1;

	q = (float)j/pas;
	borne1y = q*pas;
	borne2y = (q+1)*pas;

	if(borne2y >= r->taille)
		borne2y = r->taille-1;

	/* r�cup�rations des valeurs al�atoires aux bornes */
	int b00,b01,b10,b11;
	b00 = r->v[borne1x][borne1y];
	b01 = r->v[borne1x][borne2y];
	b10 = r->v[borne2x][borne1y];
	b11 = r->v[borne2x][borne2y];

	int v1  = interpolate(b00, b01, borne2y-borne1y, j-borne1y);
	int v2  = interpolate(b10, b11, borne2y-borne1y, j-borne1y);
	int fin = interpolate(v1, v2, borne2x-borne1x , i-borne1x);

	return fin;
}

int interpolate(int y1, int y2, int n, int delta){
	if (n==0)
	    return y1;
	if (n==1)
	    return y2;

	float a = (float)delta/n;

	float v1 = 3*pow(1-a, 2) - 2*pow(1-a,3);
	float v2 = 3*pow(a, 2)   - 2*pow(a, 3);

	return y1*v1 + y2*v2;
}


void lissage(calque* fusion, int taille){

    int x,y;
    int k,l;
    int total;
    int compteur;


    calque *lissage;
    lissage = init_calque(taille, 0);
    for (x=0; x<taille; x++){
        for (y=0; y<taille; y++){
            total = 0;
            compteur = 0;
            for (k = x-5; k <= x+5; k++){
                for (l = y-5; l <= y+5; l++){
                    if ((k >= 0) && (k < taille) && (l >= 0) && (l < taille)) {
                        compteur++;
                        total += fusion->v[k][l];
                    }
                }
            }
            lissage->v[x][y] = (float) total/compteur;
        }
    }
}
