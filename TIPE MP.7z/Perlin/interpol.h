#ifndef __interpol_h__
#define __calque_h__

int interpol(int, int, int, int);
int interpol_val(int, int, int, calque*);

#endif
