#ifndef __main_h__
#define __main_h__

#include <SDL/SDL.h>

// void colorerPixel(SDL_Surface*, int, int, Uint32);
// unsigned char aleatoire(float);
// void enregistrer_bmp(struct calque *, const char *);

#endif
