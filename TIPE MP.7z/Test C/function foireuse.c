// Source : http://khayyam.developpez.com/articles/algo/perlin/

// Le calque est carr�, d'o� l'unique param�tre.
// **v est la matrice des pixels.
// La persistance ne sert pas ici.
    
    typedef struct calque calque;
    struct calque
    {
        int **v;
        int taille;
        float persistance;
    };

// Cr�ation de calque
    calque* init_calque(int t, float p){
    calque *s = malloc(sizeof(struct calque));
    s->v = malloc(t*sizeof(int*));
    int i,j;
    for (i=0; i<t ; i++){
        s->v[i]= malloc(t*sizeof(int));
        for (j=0; j<t; j++)
            s->v[i][j]=0;
    }
    s->taille = t;
    s->persistance = p;

    return s;
    }


// Le calque de base sert de r�f�rence pour l'interpolation.
    calque* base;
    base = init_calque(WIDTH, 1);


    for (i=0; i<WIDTH; i++){
        for (j=0; j<WIDTH; j++){
            base->v[i][j]=randomgen(256);
        }
    }
    
    
// Cette fonction doit interpoler un point situ� en i,j par rapport au calque de r�f�rence "base".
// La fr�quence permet de d�terminer les "noeuds", i.e. les 4 points utilis� pour l'interpolation double.
// Une fr�quence de 2 donne (2+1)**2 = 9 noeuds, soit 4 "zones" possible.
    
int interpol(calque* base, int frequence, int i, int j){

    int tailleCell = base->taille/frequence;

    // D�finitions des bornes d'interpolation :
    int minX = (i/tailleCell) * tailleCell;
    int minY = (j/tailleCell) * tailleCell;

    int maxX=base->taille-1;
    int maxY=base->taille-1;
    if (i<tailleCell*frequence) maxX = minX + tailleCell;
    if (j<tailleCell*frequence) maxY = minY + tailleCell;

    // Variable d'interpolation :
    float x = (float) (i % tailleCell) / tailleCell;
    float y = (float) (j % tailleCell) / tailleCell;

    // On interpole en x :
    int A = base->v[minX][minY] * (1+cos(3.1415 * x))/2 + base->v[maxX][minY] * (1-cos(3.1415 *x))/2;
    int B = base->v[minX][maxY] * (1+cos(3.1415 * x))/2 + base->v[maxX][maxY] * (1-cos(3.1415 *x))/2;

    // On renvoie l'interpolation en y des deux r�sultats pr�c�dents.
    return (int) A*(cos(3.1415 * y)+1)/2 + B*(1-cos(3.1415 *y))/2;
}